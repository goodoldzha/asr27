<script type="text/javascript"> 
$(document).ready(function(){
	$.fn.adjustPanel = function(){ 
		$(this).find("ul, .subpanel").css({ 'height' : 'auto'}); 
		
		var windowHeight = $(window).height(); 
		var panelsub = $(this).find(".subpanel").height();
		var panelAdjust = windowHeight - 100;
		var ulAdjust =  panelAdjust - 25;
		
		if ( panelsub >= panelAdjust ) {	
			$(this).find(".subpanel").css({ 'height' : panelAdjust });
			$(this).find("ul").css({ 'height' : ulAdjust});
		}
		else if ( panelsub < panelAdjust ) { 
			$(this).find("ul").css({ 'height' : 'auto'}); 
		}
	};
	$("#chatpanel").adjustPanel();
	$("#alertpanel").adjustPanel();
	$(window).resize(function () { 
		$("#chatpanel").adjustPanel();
		$("#alertpanel").adjustPanel();
	});
	$("#chatpanel a:first, #alertpanel a:first").click(function() { 
		if($(this).next(".subpanel").is(':visible')){ 
			$(this).next(".subpanel").hide(); 
			$("#footpanel li a").removeClass('active'); 
		}
		else {
			$(".subpanel").hide();
			$(this).next(".subpanel").toggle(); 
			$("#footpanel li a").removeClass('active');
			$(this).toggleClass('active');
		}
		return false; 
	});
	$(document).click(function() { 
		$(".subpanel").hide();
		$("#footpanel li a").removeClass('active');
	});
	$('.subpanel ul').click(function(e) { 
		e.stopPropagation();
	});
	$("#alertpanel li").hover(function() {
		$(this).find("a.delete").css({'visibility': 'visible'});
	},function() {
		$(this).find("a.delete").css({'visibility': 'hidden'});
	});
});
</script>
<div id="footer">
	<div class="footer-bg-l"></div>
	<div class="footer-bg-m">
		<div class="copyright">
			<?php _e('Copy Right','postechin'); ?>
			<?php _e('Design','postechin'); ?><a href="http://www.postechin.com"><?php _e('Postechin','postechin'); ?></a>
		</div>
	</div>
	<div class="footer-bg-r"></div>
</div>
<div id="footpanel">
    <ul id="mainpanel">
		 <?php
		if ( is_user_logged_in() ) { 
			?>
				<li><a href="<?php bloginfo('url'); ?>/wp-admin" class="home"><?php _e('Dashboard','postechin'); ?></a></li>
			<?php if ( current_user_can('edit_posts') ) {?>
				<li><a href="<?php bloginfo('url'); ?>/wp-admin/profile.php" class="profile">View Profile <small><?php _e('View Profile','postechin'); ?></small></a></li>
				<li><a href="<?php bloginfo('url'); ?>/wp-admin/post-new.php" class="add-news">Add News <small><?php _e('Add News','postechin'); ?></small></a></li>
				<li><a href="<?php bloginfo('url'); ?>/wp-admin/post-new.php?post_type=article" class="add-article">'Add Article <small><?php _e('Add Article','postechin'); ?></small></a></li>
				<li><a href="<?php bloginfo('url'); ?>/wp-admin/post-new.php?post_type=match" class="add-match">Add Match <small><?php _e('Add Match','postechin'); ?></small></a></li>
				<li><a href="<?php bloginfo('url'); ?>/wp-admin/post-new.php?post_type=photo" class="add-photo">Add Photo <small><?php _e('Add Photo','postechin'); ?></small></a></li>
			<?php } ?>
		<?php } else {?>
		<li><a href="<?php bloginfo('url'); ?>/wp-login.php" class="user-in"><small><?php _e('Log In','postechin'); ?></small></a></li>
		<li><a href="<?php bloginfo('url'); ?>/wp-register.php" class="user-register"><small><?php _e('Register','postechin'); ?></small></a></li>

		<?php } ?>
		<li id="marquee">

<?php
$week = date('W');
$year = date('Y');
							$args=array(
								'post_type' => array('post'),
								'taxonomy' =>'',
								'term' => $term->slug,
								'post_status' => 'publish',
								'posts_per_page' => 100,
								'year' => $year,
								'w' => $week,
								);
							$my_query = null;
							$my_query = new WP_Query($args);
							$counter=1;
							if( $my_query->have_posts() ) {
							while ($my_query->have_posts()) : $my_query->the_post();
								$break=get_post_meta($post->ID, "break" , true);
								if ($break=='on' && $counter<2) {
							?>
								<li class="marq"><marquee direction=right height=20 width=635 scrollamount=3><?php _e('Important News:','postechin'); ?><?php the_title(); ?></marquee></li>
							<?php $counter++;}
							endwhile;
							}
							wp_reset_query();
						?>
		</li>
        <li id="chatpanel">
        	<a href="#" class="chat"><h6><?php _e('Last News and Articles','postechin'); ?></h6></a>
            <div class="subpanel">

            <ul>
				<li class="chat-title"><span><?php _e('Last News','postechin'); ?></span></li>
				<?php
					$additional_loop = new WP_Query("post_type=post&posts_per_page=8");
					while ($additional_loop->have_posts()) : $additional_loop->the_post(); ?>
						<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
					<?php
					endwhile;
				?>
				<br/>
				<li class="chat-title"><span><?php _e('Last Articles','postechin'); ?></span></li>
				<?php
					$additional_loop = new WP_Query("post_type=article&posts_per_page=8");
					while ($additional_loop->have_posts()) : $additional_loop->the_post(); ?>
						<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
					<?php
					endwhile;
				?>
            	
            </ul>
            </div>
        </li>
    </ul>
</div>

</div>

</body>
</html>