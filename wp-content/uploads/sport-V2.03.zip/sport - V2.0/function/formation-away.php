<?php
function aformation_4_4_2($e,$c)
{?>
	<?php $temp=explode('-',$e[0]); ?><div style="left:5%; top:47%;"  class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[1]); ?><div style="left:21%; top:12%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[2]); ?><div style="left:19%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[3]); ?><div style="left:19%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[4]); ?><div style="left:21%; top:81%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[5]); ?><div style="left:51%; top:12%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[6]); ?><div style="left:49%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[7]); ?><div style="left:49%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[8]); ?><div style="left:51%; top:81%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[9]); ?><div style="left:74%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[10]); ?><div style="left:74%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
<?php }?>
<?php
function aformation_4_3_1_2($e,$c)
{?>
	<?php $temp=explode('-',$e[0]); ?><div style="left:5%; top:47%;"  class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[1]); ?><div style="left:21%; top:12%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[2]); ?><div style="left:19%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[3]); ?><div style="left:19%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[4]); ?><div style="left:21%; top:81%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[5]); ?><div style="left:35%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[6]); ?><div style="left:49%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[7]); ?><div style="left:49%; top:60%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[8]); ?><div style="left:60%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[9]); ?><div style="left:76%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[10]); ?><div style="left:76%; top:60%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
<?php }?>
<?php
function aformation_4_3_2_1($e,$c)
{?>
	<?php $temp=explode('-',$e[0]); ?><div style="left:5%; top:47%;"  class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[1]); ?><div style="left:21%; top:12%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[2]); ?><div style="left:19%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[3]); ?><div style="left:19%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[4]); ?><div style="left:21%; top:81%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[5]); ?><div style="left:35%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[6]); ?><div style="left:58%; top:12%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[7]); ?><div style="left:54%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[8]); ?><div style="left:54%; top:60%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[9]); ?><div style="left:58%; top:81%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[10]); ?><div style="left:76%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
<?php }?>
<?php
function aformation_4_1_2_3($e,$c)
{?>
	<?php $temp=explode('-',$e[0]); ?><div style="left:5%; top:47%;"  class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[1]); ?><div style="left:21%; top:12%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[2]); ?><div style="left:19%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[3]); ?><div style="left:19%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[4]); ?><div style="left:21%; top:81%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[5]); ?><div style="left:35%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[6]); ?><div style="left:54%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[7]); ?><div style="left:54%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[8]); ?><div style="left:76%; top:22%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[9]); ?><div style="left:76%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[10]); ?><div style="left:76%; top:72%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
<?php }?>
<?php
function aformation_4_2_3_1($e,$c)
{?>
	<?php $temp=explode('-',$e[0]); ?><div style="left:5%; top:47%;"  class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[1]); ?><div style="left:21%; top:12%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[2]); ?><div style="left:19%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[3]); ?><div style="left:19%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[4]); ?><div style="left:21%; top:81%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[5]); ?><div style="left:35%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[6]); ?><div style="left:35%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[7]); ?><div style="left:54%; top:22%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[8]); ?><div style="left:60%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[9]); ?><div style="left:54%; top:72%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[10]); ?><div style="left:80%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
<?php }?>
<?php
function aformation_4_2_1_3($e,$c)
{?>
	<?php $temp=explode('-',$e[0]); ?><div style="left:5%; top:47%;"  class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[1]); ?><div style="left:21%; top:12%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[2]); ?><div style="left:19%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[3]); ?><div style="left:19%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[4]); ?><div style="left:21%; top:81%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[5]); ?><div style="left:35%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[6]); ?><div style="left:35%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>

	<?php $temp=explode('-',$e[7]); ?><div style="left:54%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[8]); ?><div style="left:76%; top:22%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[9]); ?><div style="left:76%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[10]); ?><div style="left:76%; top:72%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
<?php }?>
<?php
function aformation_4_3_3($e,$c)
{?>
	<?php $temp=explode('-',$e[0]); ?><div style="left:5%; top:47%;"  class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[1]); ?><div style="left:21%; top:12%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[2]); ?><div style="left:19%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[3]); ?><div style="left:19%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[4]); ?><div style="left:21%; top:81%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[5]); ?><div style="left:48%; top:22%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[6]); ?><div style="left:48%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[7]); ?><div style="left:48%; top:72%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[8]); ?><div style="left:76%; top:22%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[9]); ?><div style="left:76%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[10]); ?><div style="left:76%; top:72%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
<?php }?>
<?php
function aformation_3_4_1_2($e,$c)
{?>
	<?php $temp=explode('-',$e[0]); ?><div style="left:5%; top:47%;"  class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[1]); ?><div style="left:19%; top:22%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[2]); ?><div style="left:19%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[3]); ?><div style="left:19%; top:72%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[4]); ?><div style="left:35%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[5]); ?><div style="left:35%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[6]); ?><div style="left:48%; top:17%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[7]); ?><div style="left:48%; top:76%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[8]); ?><div style="left:60%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[9]); ?><div style="left:76%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[10]); ?><div style="left:76%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
<?php }?>
<?php
function aformation_3_3_2_2($e,$c)
{?>
	<?php $temp=explode('-',$e[0]); ?><div style="left:5%; top:47%;"  class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[1]); ?><div style="left:19%; top:22%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[2]); ?><div style="left:19%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[3]); ?><div style="left:19%; top:72%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[4]); ?><div style="left:35%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[5]); ?><div style="left:48%; top:17%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[6]); ?><div style="left:48%; top:76%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[7]); ?><div style="left:55%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[8]); ?><div style="left:55%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[9]); ?><div style="left:76%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[10]); ?><div style="left:76%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
<?php }?>
<?php
function aformation_3_4_3($e,$c)
{?>
	<?php $temp=explode('-',$e[0]); ?><div style="left:5%; top:47%;"  class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[1]); ?><div style="left:19%; top:22%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[2]); ?><div style="left:19%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[3]); ?><div style="left:19%; top:72%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>

	<?php $temp=explode('-',$e[4]); ?><div style="left:50%; top:12%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[5]); ?><div style="left:45%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[6]); ?><div style="left:45%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[7]); ?><div style="left:50%; top:81%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[8]); ?><div style="left:76%; top:22%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[9]); ?><div style="left:76%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[10]); ?><div style="left:76%; top:72%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
<?php }?>
<?php
function aformation_5_2_2_1($e,$c)
{?>
	<?php $temp=explode('-',$e[0]); ?><div style="left:5%; top:47%;"  class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[1]); ?><div style="left:22%; top:12%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[2]); ?><div style="left:19%; top:28%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[3]); ?><div style="left:19%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[4]); ?><div style="left:19%; top:65%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[5]); ?><div style="left:22%; top:81%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[6]); ?><div style="left:45%; top:35%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[7]); ?><div style="left:45%; top:58%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[8]); ?><div style="left:60%; top:23%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	<?php $temp=explode('-',$e[9]); ?><div style="left:60%; top:70%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
	
	<?php $temp=explode('-',$e[10]); ?><div style="left:76%; top:47%;" class="away-squad"><span class="<?php echo $c;?>"><?php echo $temp[0]; ?></span><?php $temp=explode('[',$temp[1]); echo $temp[0]; ?></div>
<?php }?>