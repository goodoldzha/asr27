﻿<div class="search-input">
	<div id="search-form">
		<form method="get" id="searchform1" action="<?php echo home_url();; ?>/">
			<input type="submit" id="searchsubmit" value="<?php _e('Search','13floor'); ?>" />
			<input type="text" value="" name="s" id="searchinput" />
		</form>
	</div> <!-- end searchform -->
</div>