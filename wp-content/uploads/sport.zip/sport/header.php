<?php load_theme_textdomain( 'postechin' ) ; ?>
<div class="header">
	<div class="head-img">
	</div>
	
		<?php wp_nav_menu('menu=main&after=<span class=container></span>'); ?>
	
</div>
