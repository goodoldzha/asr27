<?php
/*
Template Name: Full Width Page
*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">

	<title><?php bloginfo('name'); ?><?php wp_title(); ?></title>

	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />	
	<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats please -->

	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<?php wp_get_archives('type=monthly&format=link'); ?>
	<script type="text/javascript" src="wp-content/themes/sport/jquery.min.js" ></script>
	<script type="text/javascript" src="wp-content/themes/sport/jquery-ui.min.js" ></script>
	 <?php wp_head(); ?> 
</head>
<body>
<div id="wrapper">
	<?php get_header(); ?>
	<div class="middle">
		<div id="main-full">
			<?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>
			<h2 class="full-title"><img src="<?php bloginfo('template_directory');?>/images/list-icon.png"/><?php the_title(); ?></h2>
			<div class="full-content">
				<div class="full-thumb"><?php if ( has_post_thumbnail() ) { the_post_thumbnail('full-thumbnail'); }?></div>
				<p><?php the_content(); ?></p>
			</div>
			<div class="full-meta">
					<h5><img src="<?php bloginfo('template_directory');?>/images/date.png"/><?php echo get_the_date(); echo '   ';?></h5>
					<h6><img src="<?php bloginfo('template_directory');?>/images/author.png"/><?php echo get_the_author(); ?></h6>
					<h5><img src="<?php bloginfo('template_directory');?>/images/cat.png"/>		
						<?php echo get_the_term_list( get_the_ID(),'post_cat', '', ', ', ', ' );?>		
						<?php echo get_the_term_list( get_the_ID(),'team_cat', '', ', ', ', ' );?>		
						<?php echo get_the_term_list( get_the_ID(),'player_cat', '', ', ', ', ' );?>			
					</h5>
			</div>
		
			<?php endwhile; ?>


			<?php else : ?>

				<div class="post">
					<h2><?php _e('Not Found','postechin'); ?></h2>
				</div>

			<?php endif; ?>
		</div>
	</div>
	<?php get_footer(); ?>	

</div>

</body>
</html>