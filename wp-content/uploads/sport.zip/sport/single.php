<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">

	<title><?php bloginfo('name'); ?><?php wp_title(); ?></title>

	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />	
	<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats please -->

	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<?php wp_get_archives('type=monthly&format=link'); ?>
	<script type="text/javascript" src="wp-content/themes/sport/jquery.min.js" ></script>
	<script type="text/javascript" src="wp-content/themes/sport/jquery-ui.min.js" ></script>
	 <?php wp_head(); ?> 
</head>
<body>
<div id="wrapper">
	<?php get_header(); ?>
	<div class="middle">
		<div id="main">
			<?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>
			<h2 class="single-title"><img src="<?php bloginfo('template_directory');?>/images/list-icon.png"/><?php the_title(); ?></h2>
			<div class="single-content">
				<div class="single-thumb"><?php if ( has_post_thumbnail() ) { the_post_thumbnail('single-thumbnail'); }?></div>
				<p><?php the_content(); ?></p>
			</div>
			
			<div class="comments-template">
				<?php comments_template(); ?>
			</div>
			
			<div class="single-meta">
				<h5><img src="<?php bloginfo('template_directory');?>/images/date.png"/><?php echo get_the_date(); echo '   ';?></h5>
				<h6><img src="<?php bloginfo('template_directory');?>/images/author.png"/><?php echo get_the_author(); ?></h6>
				<h5><img src="<?php bloginfo('template_directory');?>/images/cat.png"/>		
					<?php echo get_the_term_list( get_the_ID(),'post_cat', '', ', ', ', ' );?>		
					<?php echo get_the_term_list( get_the_ID(),'team_cat', '', ', ', ', ' );?>		
					<?php echo get_the_term_list( get_the_ID(),'player_cat', '', ', ', ', ' );?>			
				</h5>
				<div class="share">
					<a href="http://del.icio.us/post?url=<?php the_permalink() ?>&title=<?php the_title(); ?>"><img src="<?php bloginfo('template_directory');?>/images/panel/delicious.png"/></a>
					<a href="http://twitter.com/home?status=<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><img src="<?php bloginfo('template_directory');?>/images/panel/twitter.png"/></a>
					<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&t=<?php the_title(); ?>" target="blank"><img src="<?php bloginfo('template_directory');?>/images/panel/facebook.png"/></a>
				</div>
			</div>
			
		
			<?php endwhile; ?>


			<?php else : ?>

				<div class="post">
					<h2><?php _e('Not Found','postechin'); ?></h2>
				</div>

			<?php endif; ?>
		</div>
		<div id="sidebar">
			<?php get_sidebar('Sidebar'); ?>
		</div>
	</div>
	<?php get_footer(); ?>	

</div>

</body>
</html>