	
				<?php
						$args=array(
						'post_type' => array('post'),
						'taxonomy' =>'',
						'term' => $term->slug,
						'post_status' => 'publish',
						'posts_per_page' => 100
						);
					$my_query = null;
					$my_query = new WP_Query($args);
					$counter=1;
					if( $my_query->have_posts() ) {
					while ($my_query->have_posts()) : $my_query->the_post();
						$slider=get_post_meta($post->ID, "slider" , true);
						if ($slider=='on' && $counter<5) {
					?>
						<div id="item-<?php echo $counter; ?>" class="item-content" style="">
							<div class="slide-thumb"><?php the_post_thumbnail('single-thumbnail'); ?></div>
							<div class="slide-block">
								<a href="<?php the_permalink(); ?>"><h2><?php the_title(); ?></h2></a>
								<p><?php the_excerpt(); ?></p>
								<div class="button"><a href="<?php the_permalink(); ?>"><?php _e('More','postechin'); ?></a></div>
							</div>
						</div>	
					<?php $counter++;}
					endwhile;
					}
					wp_reset_query();
				?>

	
	<div id="slider-list" >
		<ul>
			<?php
						$args=array(
						'post_type' => array('post'),
						'taxonomy' =>'',
						'term' => $term->slug,
						'post_status' => 'publish',
						'posts_per_page' => 100
						);
					$my_query = null;
					$my_query = new WP_Query($args);
					$counter=1;
					if( $my_query->have_posts() ) {
					while ($my_query->have_posts()) : $my_query->the_post();
						$slider=get_post_meta($post->ID, "slider" , true);
						if ($slider=='on' && $counter<5) {
					?>
							 <li id="nav-item-<?php echo $counter ?>" title="<?php the_title(); ?>"><a title="#item-<?php echo $counter; ?>"><?php the_post_thumbnail(); ?></a></li>
					<?php $counter++;}
					endwhile;
					}
					wp_reset_query();
					?>
		</ul>
	</div>